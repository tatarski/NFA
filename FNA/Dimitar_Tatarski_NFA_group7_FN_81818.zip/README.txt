Имена: Димитър Николаев Татарски
СПЕЦИАЛНОСТ: КН
ГРУПА: 7
ФН: 81818
ЛИНК КЪМ GITHUB REPO:
https://github.com/tatarski/NFA